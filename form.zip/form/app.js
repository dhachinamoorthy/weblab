const {urlencoded} = require('body-parser');
const express = require('express');
const app= express();
const mongoose = require('mongoose');
const College = require('./views/models/course');

app.set('view engine','ejs');
app.use(urlencoded({extended:true}));
mongoose.connect("mongodb://127.0.0.1:27017/College",{
  useNewUrlParser : true,
  useUnifiedTopology : true,
}).then(
  (result) => {
    app.listen(4444);
    console.log("Listening to 4444");
  }
).catch(
  (err) => console.log(err)
)

app.get('/',(req,res) =>{
  College.find().then(
    (result) =>   res.render('form',{courses:result})
  )

}
)

app.post('/add',(req,res) => {
  const c = new College(req.body);
  College.findOne({$and : [{College:req.body.College },{Course:req.body.Course}]}).then(
    (result) => {
      if(result != null){
      College.findOneAndUpdate(
        {College:c.College},{
          $set : {
            Fee : parseInt(req.body.Fee)
          }
        }
      ).then(
        (result) =>       console.log('success')
      )

      }
      else
      {
        c.save()
        console.log('success')
      }
    }
  )
  
})

app.post('/delete',(req,res) => {
  College.findOneAndDelete(
    {College:req.body.College},function (err, docs) {
      if (err){
          console.log(err)
      }
      else{
          console.log("Deleted User : ", docs);
      }
  }
  )
})
