const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const courseSchema = new Schema(
    {
        College : {
            type:String,
            required : true
        },
        Course : {
            type:String,
            required:true
        },
        Fee : {
            type:Number,
            required : true
        }
    }
);

const College = mongoose.model('College',courseSchema);
module.exports = College;