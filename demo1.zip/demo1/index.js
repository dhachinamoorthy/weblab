const express = require('express');
const mongoose = require('mongoose');
const bodyparser = require('body-parser');

const app = express();

app.use(express.static('public'));
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({
    extended:true
}))

mongoose.connect('mongodb://localhost:27017/dbna',{
    useNewUrlParser : true,
    useUnifiedTopology: true
});

var db = mongoose.connection;
db.on('error',()=>{
console.log("error")
})

db.once('open',()=>console.log('connected to database'))

app.get("/",(req,res)=>{
res.sendfile(__dirname + "/index.html")
})

app.post("/add",(req,res)=>{
    var name=req.body.name;
    var email=req.body.email;
    var number=req.body.number;

    var data={
        "name":name,
        "email":email,
        "number":number
    }

    db.collection('users').insertOne(data,(err,collection)=>{
        if(err){
            throw err;
        }console.log("plan success")
        
    })
    
})
app.listen(3000);